package com.ib_soft_startup_animation;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

/**
 * Created by IB-soft on 1/25/2018.
 */

public class Startup_Animation extends Activity {
    @Override
    protected void onCreate(Bundle saveInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_startup_animation);

        Thread timerThread = new Thread() {
            public void run() {
                try {
                    sleep(7000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    Intent intent = new Intent(Startup_Animation.this, MainActivity.class);
                    startActivity(intent);

                }
            }
        };
        timerThread.start();

    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        finish();
    }




    @Override
    protected void onStart() {
        ImageView image = (ImageView)findViewById(R.id.second_animation);
        Animation animation = AnimationUtils.loadAnimation (getApplicationContext(),
                R.anim.second_anim);
        image.startAnimation(animation);

        ImageView imag = (ImageView)findViewById(R.id.first_animation);
        Animation animatio = AnimationUtils.loadAnimation (getApplicationContext(),
                R.anim.first_anim);
        imag.startAnimation(animatio);



        ImageView images = (ImageView)findViewById(R.id.third_animation);
        Animation animations = AnimationUtils.loadAnimation (getApplicationContext(),
                R.anim.animation_fade_front);
        images.startAnimation(animations);


        ImageView image1 = (ImageView)findViewById(R.id.anim_4);
        Animation animations1 = AnimationUtils.loadAnimation (getApplicationContext(),
                R.anim.animation_fade_back);
        image1.startAnimation(animations1);




        ImageView image2 = (ImageView)findViewById(R.id.anim_5);
        Animation animations2 = AnimationUtils.loadAnimation (getApplicationContext(),
                R.anim.animation_fade_back2);
        image2.startAnimation(animations2);





        super.onStart();

    }

}

